import time
import random

header = "gamma1_Cz,gamma2_Cz,gamma3_Cz,gamma4_Cz,gamma5_Cz,gamma6_Cz," \
         "gamma1_Fz,gamma2_Fz,gamma3_Fz,gamma4_Fz,gamma5_Fz,gamma6_Fz"
         
# 開啟文本檔案以追加模式寫入
with open(r"D:\temperature\numbers.txt", "a") as file:
    file.write(header + "\n")  # 寫入標題，換行
    file.flush()
    while True:
        row = [f"{random.uniform(0, 2):.4f}" for _ in range(12)]
        # 將生成的小數組合成一行
        row_data = ",".join(row)
        # 寫入文件
        file.write(row_data + "\n")
        file.flush()  # 強制將緩衝區內容寫入文件
        print(row_data)  # 顯示當前行資料
        time.sleep(1)  # 每秒產生一行數據
