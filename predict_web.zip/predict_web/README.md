web --->>> C:\Users\user\Downloads\predict_web\predict_web
![image](https://github.com/user-attachments/assets/d08aff4b-a5a7-44aa-b624-147e1fe400fd)
