import os
import numpy as np

# 指定資料夾路徑
folder_path = r"C:\Users\user\OneDrive\桌面\immediate_data\baseline\CH1"

# 定義頻段範圍 (索引範圍)
gamma_ranges = {
    "gamma1": (33, 42),
    "gamma2": (43, 53),
    "gamma3": (54, 63),
    "gamma4": (64, 73),
    "gamma5": (74, 83),
    "gamma6": (84, 94),
}

# 指定要處理的行數 (索引從 0 開始，假設取第 0 行)
target_row_index = 0

# 初始化結果字典
results = {key: [] for key in gamma_ranges.keys()}

# 定義函數計算頻段平均值
def get_features(data_row, start_idx, end_idx):
    return np.mean(data_row[start_idx:end_idx + 1])

# 遍歷資料夾中的每個檔案
for filename in os.listdir(folder_path):
    if filename.endswith(".txt"):
        file_path = os.path.join(folder_path, filename)
        
        # 讀取數據
        data = np.loadtxt(file_path)
        
        # 確保目標行存在
        if target_row_index < data.shape[0]:
            # 選取目標行數據
            data_row = data[target_row_index]
            
            # 計算每個頻段的平均值
            for gamma, (start, end) in gamma_ranges.items():
                avg_value = get_features(data_row, start, end)
                results[gamma].append(avg_value)

# 輸出計算結果
for gamma, values in results.items():
    print(f"{gamma} 平均值: {np.mean(values):.2f} (共 {len(values)} 個檔案)")
