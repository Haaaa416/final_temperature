from flask import Flask, render_template, Response, request, jsonify
import pandas as pd
import numpy as np
import glob
import os
from time import sleep
from tensorflow.keras.models import load_model
import plotly
import plotly.express as px
import json
from sqlalchemy import create_engine, text
import threading
from collections import deque
import subprocess
app = Flask(__name__)

# Database configuration
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = ''
DB_NAME = 'eeg_data'

engine = create_engine(f'mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}?charset=utf8mb4')

# Model configuration
models = {}
current_model = None
is_predicting = False
prediction_thread = None

# Initialize variables
folder_path = r"D:\temperature" #是模擬的程式碼txt之後要註解
#folder_path = r"C:\Users\user\immediate_data\data"
#folder_path = r"C:\Users\user\Downloads\predict_web\predict_web"
last_sequence_index = {}
feature_columns = ['gamma1_Cz', 'gamma2_Cz', 'gamma3_Cz', 'gamma4_Cz', 'gamma5_Cz', 'gamma6_Cz',
                  'gamma1_Fz', 'gamma2_Fz', 'gamma3_Fz', 'gamma4_Fz', 'gamma5_Fz', 'gamma6_Fz']
time_steps = 3

# Create a deque to store the last 60 seconds of predictions
prediction_data = deque(maxlen=60)

def load_all_models():
    """Load all available models"""
    model_paths = {
        'model1': 'position1_model.h5',
        'model2': 'position2_model.h5',
        'model3': 'position3_model.h5',
        'model4': 'position4_model.h5',
        'model5': 'position5_model.h5',
        'model6': 'position6_model.h5',
        'model7': 'position7_model.h5',
        'model8': 'position8_model.h5',
        'model9': 'position9_model.h5',
        'model10': 'position10_model.h5',
        'model11': 'position11_model.h5',
        'model12': 'LSTM_model.h5'
    }
    
    for model_name, model_path in model_paths.items():
        try:
            if os.path.exists(model_path):
                models[model_name] = load_model(model_path)
                print(f'Loaded {model_name} from {model_path}')
                print('success')
            else:
                print(f'Model file not found: {model_path}')
        except Exception as e:
            print(f'Error loading {model_name}: {e}')

def predict_and_save():
    global is_predicting
    #這段是模擬程式碼，要記得之後用腦波儀器的時候要註解
    try:
        sim_process = subprocess.Popen(['python', 'num.py'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print("模擬 num.py 啟動中...")
    except Exception as e:
        print(f"無法啟動 num.py：{e}")
        return  # 失敗就不繼續預測
    try:
        arduino_process = subprocess.Popen(['python', 'D:/temperature/sketch_jul12a/cody.py'],
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.STDOUT,
                                           text=True)
        print("Arduino 控制程式 cody.py 啟動")
    except Exception as e:
        print(f"無法啟動 cody.py：{e}")
        return
    try:
        while is_predicting:
            if current_model is None:
                sleep(1)
                continue
                
            txt_files = glob.glob(f"{folder_path}/*.txt")
            
            for file in txt_files:
                try:
                    data_val = pd.read_csv(file, header=0, names=feature_columns)

                except Exception as e:
                    print(f"Cannot read file {file}, error: {e}")
                    continue

                if file not in last_sequence_index:
                    last_sequence_index[file] = -1

                total_lines = len(data_val)
                max_sequence_index = total_lines - time_steps

                if last_sequence_index[file] < max_sequence_index:
                    sequences_to_process = range(last_sequence_index[file] + 1, max_sequence_index + 1)
                    X_val_new = []
                    prediction_times = []

                    for i in sequences_to_process:
                        X_sequence = data_val.iloc[i:i + time_steps][feature_columns].values
                        try:
                            X_sequence = X_sequence.astype(float)
                        except ValueError as e:
                            print(f"Non-numeric data found, error: {e}")
                            continue
                        X_val_new.append(X_sequence)
                        prediction_times.append(i + time_steps)

                    X_val_new = np.array(X_val_new)

                    if len(X_val_new) > 0:
                        y_pred_val = current_model.predict(X_val_new)
                        predictions = (y_pred_val.flatten() > 0.5).astype(int)
                        
                        # Update prediction_data deque
                        for time, pred in zip(prediction_times, predictions):
                            prediction_data.append({'Time (sec)': time, 'Prediction': pred})
                        
                        # Save to data.csv for web display
                        #pd.DataFrame(list(prediction_data)).to_csv('data.csv', index=False)
                        
                        # Save to individual prediction file
                        file_name = os.path.splitext(os.path.basename(file))[0]
                        output_file_name = r"D:\temperature\predict_web\predictions.csv"
                        pd.DataFrame({
                            'Time (sec)': prediction_times,
                            'Prediction': predictions
                        }).to_csv(output_file_name, index=False, mode='a', 
                                header=not os.path.exists(output_file_name))
                        
                        last_sequence_index[file] = max_sequence_index

            sleep(1)
    finally:
        # 當 is_predicting=False 時結束 → 關閉模擬 num.py 子程序
        if sim_process and sim_process.poll() is None:
            sim_process.terminate()
            print("模擬 num.py 已終止")

def create_line_chart(data):
    if data is None or len(data) == 0:
        return None
    
    try:
        data['Time (sec)'] = pd.to_numeric(data['Time (sec)'], errors='coerce')
        fig = px.line(data, x='Time (sec)', y='Prediction', title='Real-time Data (Last 60 seconds)')
        fig.update_layout(
            xaxis_title="Time (sec)",
            yaxis_title="Prediction",
            hovermode='x unified',
            margin=dict(l=20, r=20, t=40, b=20),
            yaxis=dict(range=[-0.1, 1.1]),
            plot_bgcolor='white',
            paper_bgcolor='white',
            showlegend=False
        )
        
        # ???�???????��???�?????
        fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='LightGray')
        fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='LightGray')
        
        # ??��????��???????????????
        fig.update_traces(line=dict(color='#1f77b4', width=2))
        
        return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    except Exception as e:
        print(f"Error creating chart: {e}")
        return None

def load_csv_data():
    try:
        return pd.DataFrame(list(prediction_data))
        print("📊 資料載入成功", data.head())
        return data
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

@app.route('/start-prediction', methods=['POST'])
def start_prediction():
    global current_model, is_predicting, prediction_thread
    
    try:
        data = request.get_json()
        model_name = data.get('model')
        
        if model_name not in models:
            return jsonify({'success': False, 'message': f'Model {model_name} not found'})
        
        # Stop existing prediction if running
        is_predicting = False
        if prediction_thread and prediction_thread.is_alive():
            prediction_thread.join()
        
        # Clear previous prediction data
        prediction_data.clear()
        
        # Set new model and start prediction
        current_model = models[model_name]
        is_predicting = True
        prediction_thread = threading.Thread(target=predict_and_save, daemon=True)
        prediction_thread.start()
        
        return jsonify({'success': True, 'message': f'Started prediction with {model_name}'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/stop-prediction', methods=['POST'])
def stop_prediction():
    global is_predicting
    is_predicting = False
    return jsonify({'success': True, 'message': 'Prediction stopped'})

@app.route('/chart-stream')
def chart_stream():
    print("📡 chart-stream 已被前端連線")
    def generate():
        while True:
            data = load_csv_data()
            if data is not None and not data.empty:
                chart_json = create_line_chart(data)
                if chart_json:
                    yield f"data: {chart_json}\n\n"
            sleep(1)

    return Response(generate(), mimetype='text/event-stream')

@app.route('/')
def index():
    data = load_csv_data()
    chart_json = create_line_chart(data)
    return render_template('index.html', chart_json=chart_json)

@app.route('/save-all-data', methods=['POST'])
def save_all_data():
    try:
        data = request.get_json()
        participant_name = data['name'].replace(' ', '_')
        
        with engine.connect() as conn:
            create_participant_table_sql = text("""
                CREATE TABLE IF NOT EXISTS participant_data (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50),
                    age INT,
                    model_option VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute(create_participant_table_sql)
            
            insert_participant_sql = text("""
                INSERT INTO participant_data (name, age, model_option)
                VALUES (:name, :age, :model_option)
            """)
            result = conn.execute(insert_participant_sql, {
                'name': data['name'],
                'age': data['age'],
                'model_option': data['model_option']
            })
            participant_id = result.lastrowid
            
            table_name = f"{participant_id}_data_{participant_name}"
            create_individual_table_sql = text(f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    time_sec FLOAT,
                    prediction FLOAT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute(create_individual_table_sql)
            
            current_data = load_csv_data()
            if current_data is not None and not current_data.empty:
                for _, row in current_data.iterrows():
                    insert_data_sql = text(f"""
                        INSERT INTO {table_name} (time_sec, prediction)
                        VALUES (:time, :prediction)
                    """)
                    conn.execute(insert_data_sql, {
                        'time': row['Time (sec)'],
                        'prediction': row['Prediction']
                    })
            
            conn.commit()
            return jsonify({
                'success': True, 
                'message': f'Data saved successfully to {table_name}',
                'table_name': table_name
            })
            
    except Exception as e:
        print(f"Error saving data: {e}")
        return jsonify({'success': False, 'message': str(e)})

if __name__ == '__main__':
    load_all_models()  # Load all models at startup
    app.run(debug=True, threaded=True)