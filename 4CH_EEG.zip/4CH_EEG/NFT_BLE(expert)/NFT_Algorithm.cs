﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NFT_BLE_expert_
{
    class NFT_Algorithm
    {
        int input_len;
        float score;
        double[] input_signail;

        public NFT_Algorithm(int inputlength, int outputlength)
        {
          

        }
    }
}
